package com.sanbhu.deployment.script.controller;

public class BaseHtmlController {

}
