package com.sanbhu.deployment.script.controller.html;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sanbhu.deployment.script.controller.BaseHtmlController;

@Controller
public class PatchController extends BaseHtmlController {

	@RequestMapping("/")
	public String patchCreation(Map<String, Object> model) {
		return "patchCreation/index";
	}

	@RequestMapping("/createScript")
	public String createScript(Map<String, Object> model) {
		return "createScript/index";
	}
}