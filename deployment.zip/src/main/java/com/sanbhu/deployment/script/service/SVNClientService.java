package com.sanbhu.deployment.script.service;

import java.util.List;

import com.sanbhu.deployment.script.bo.SVNFileDetail;
import com.sanbhu.deployment.script.bo.SVNLogDetail;

public interface SVNClientService {
	public List<SVNFileDetail> getSVNFileList(final String repoURL, final String userName, final String password);

	public List<SVNLogDetail> getSVNLogDetailList(final String repoURL, final String userName, final String password,
			final Long startRevision, final Long endRevision);
}
