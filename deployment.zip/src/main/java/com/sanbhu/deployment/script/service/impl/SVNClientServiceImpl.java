package com.sanbhu.deployment.script.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tmatesoft.svn.core.SVNDirEntry;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNLogEntry;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.auth.ISVNAuthenticationManager;
import org.tmatesoft.svn.core.internal.io.dav.DAVRepositoryFactory;
import org.tmatesoft.svn.core.internal.io.fs.FSRepositoryFactory;
import org.tmatesoft.svn.core.internal.io.svn.SVNRepositoryFactoryImpl;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.io.SVNRepositoryFactory;
import org.tmatesoft.svn.core.wc.SVNWCUtil;

import com.sanbhu.deployment.script.bo.SVNFileDetail;
import com.sanbhu.deployment.script.bo.SVNLogDetail;
import com.sanbhu.deployment.script.service.SVNClientService;

public class SVNClientServiceImpl implements SVNClientService {
	private static final Log logger = LogFactory.getLog("SVNClientServiceImpl");
	static {
		DAVRepositoryFactory.setup();
		SVNRepositoryFactoryImpl.setup();
		FSRepositoryFactory.setup();
	}

	public List<SVNFileDetail> getSVNFileList(final String repoURL, final String userName, final String password) {
		final List<SVNFileDetail> svnFileDetailList = new ArrayList<SVNFileDetail>();
		try {
			SVNRepository repository = SVNRepositoryFactory.create(SVNURL.parseURIEncoded(repoURL));
			ISVNAuthenticationManager authManager = SVNWCUtil.createDefaultAuthenticationManager(userName, password);
			repository.setAuthenticationManager(authManager);
			Collection<?> entries = repository.getDir("", -1, null, (Collection<?>) null);
			Iterator<?> iterator = entries.iterator();
			while (iterator.hasNext()) {
				SVNDirEntry svnDirEntry = (SVNDirEntry) iterator.next();
				SVNFileDetail svnFileDetail = new SVNFileDetail();
				svnFileDetail.setAuthorName(svnDirEntry.getAuthor());
				svnFileDetail.setName(svnDirEntry.getName());
				svnFileDetail.setRelativePath(svnDirEntry.getRelativePath());
				svnFileDetail.setRevisionNumber(Long.valueOf(svnDirEntry.getRevision()));
				svnFileDetailList.add(svnFileDetail);
			}
		} catch (SVNException exception) {
			logger.error("SVN Exception - " + exception.getLocalizedMessage());
		}
		return svnFileDetailList;
	}

	public List<SVNLogDetail> getSVNLogDetailList(final String repoURL, final String userName, final String password,
			final Long startRevision, final Long endRevision) {
		List<SVNLogDetail> svnLogDetailList = new ArrayList<SVNLogDetail>();
		try {
			SVNRepository repository = SVNRepositoryFactory.create(SVNURL.parseURIEncoded(repoURL));
			ISVNAuthenticationManager authManager = SVNWCUtil.createDefaultAuthenticationManager(userName, password);
			repository.setAuthenticationManager(authManager);
			Collection<?> logEntries = repository.log(new String[] { repoURL }, null, startRevision, endRevision, true,
					true);
			Iterator<?> iterator = logEntries.iterator();
			while (iterator.hasNext()) {
				SVNLogEntry svnLogEntry = (SVNLogEntry) iterator.next();
				SVNLogDetail svnLogDetail = new SVNLogDetail();
				svnLogDetail.setMessage(svnLogEntry.getMessage());
				svnLogDetail.setRevisionNumber(svnLogEntry.getRevision());
				svnLogDetail.setAuthor(svnLogEntry.getAuthor());
				svnLogDetail.setDate(svnLogEntry.getDate().toString());
			}
		} catch (SVNException exception) {
			logger.error("SVN Exception - " + exception.getLocalizedMessage());
		}
		return svnLogDetailList;
	}
}
