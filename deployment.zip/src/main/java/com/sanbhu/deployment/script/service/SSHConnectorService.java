package com.sanbhu.deployment.script.service;

import com.jcraft.jsch.Session;

public interface SSHConnectorService {
	public Session connectToServer(final String serverIPAddress, final Integer port, final String userName,
			final String password);

	public Session performLoginToServerUser(final Session session, final String userName, final String password);
	
	public void disconnectToServer(final Session session);
}
